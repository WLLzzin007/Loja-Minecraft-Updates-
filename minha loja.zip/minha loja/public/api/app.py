from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# --- NOSSO "BANCO DE DADOS" DE PRODUTOS ---
# (Movido para fora da função para ser global e ter "memória")
# Adicionamos a chave "stock" (estoque) em cada um
DB_PRODUTOS = [
    { "id": 1, "nome": "Box de pedra", "preco": 19.90, "imagem": "img/produtos/box-pedra.png", "stock": 50 },
    { "id": 2, "nome": "Box de cobre", "preco": 49.90, "imagem": "img/produtos/box-cobre.png", "stock": 30 },
    { "id": 3, "nome": "Box de Ferro", "preco": 99.90, "imagem": "img/produtos/box-ferro.png", "stock": 15 },
    { "id": 4, "nome": "Box de Diamante", "preco": 199.90, "imagem": "img/produtos/box-diamante.png", "stock": 5 }, # Estoque baixo!
]

# --- Nossas Funções (Endpoints) ---

@app.route("/api/produtos")
def get_produtos():
    """
    Função que retorna a lista de produtos do nosso "banco de dados".
    """
    print("LOG: Requisição /api/produtos recebida!")
    # Agora ele retorna a variável global, que pode mudar
    return jsonify(DB_PRODUTOS)

# ... (antes do if __name__ == "__main__":) ...

@app.route("/api/finalizar-compra", methods=['POST'])
def finalizar_compra():
    """
    Recebe o carrinho e os dados de entrega do cliente, verifica o estoque,
    "processa" o pagamento e diminui o estoque.
    """
    print("LOG: Requisição /api/finalizar-compra recebida!")
    
    dados = request.get_json()
    carrinho_cliente = dados.get('carrinho') 
    dados_entrega = dados.get('dados_entrega') # <-- NOVO: Recebe os dados de entrega

    if not carrinho_cliente:
        return jsonify({"status": "erro", "mensagem": "Carrinho vazio."}), 400

    # --- NOVO: Validação básica dos dados de entrega ---
    if not dados_entrega or not all(key in dados_entrega for key in ['nomeCompleto', 'email', 'endereco', 'cidade', 'estado', 'cep']):
        return jsonify({"status": "erro", "mensagem": "Dados de entrega incompletos ou inválidos."}), 400

    # --- 1. Verificação de Estoque ---
    erros_estoque = []
    
    db_map = {produto['id']: produto for produto in DB_PRODUTOS}

    for item_carrinho in carrinho_cliente:
        item_id = item_carrinho['id']
        item_qtde = item_carrinho['qtde']
        
        if item_id not in db_map:
            erros_estoque.append(f"Produto ID {item_id} não encontrado.")
            continue
        
        produto_db = db_map[item_id]
        
        if item_qtde > produto_db['stock']:
            erros_estoque.append(f"Estoque insuficiente para '{produto_db['nome']}'. Pedido: {item_qtde}, Estoque: {produto_db['stock']}.")
    
    if erros_estoque:
        print(f"ERRO DE ESTOQUE: {', '.join(erros_estoque)}")
        return jsonify({
            "status": "erro", 
            "mensagem": " ".join(erros_estoque)
        }), 400

    # --- 2. Se tudo estiver OK, "Processa" a Compra (Diminui o estoque) ---
    print("\n--- NOVO PEDIDO RECEBIDO ---")
    print("Dados de Entrega:", dados_entrega) # <-- NOVO: Imprime os dados de entrega
    print("Itens do Pedido:")
    for item_carrinho in carrinho_cliente:
        item_id = item_carrinho['id']
        item_qtde = item_carrinho['qtde']
        
        produto_db = db_map[item_id] # Obtém o produto do DB_PRODUTOS
        produto_db['stock'] -= item_qtde # Diminui o estoque
        print(f"- {item_qtde}x {produto_db['nome']} (Novo estoque: {produto_db['stock']})")
    print("---------------------------\n")

    # Retorna uma mensagem de sucesso
    return jsonify({
        "status": "sucesso",
        "mensagem": "Compra realizada com sucesso! O estoque foi atualizado."
    })

# ... (após a função finalizar_compra) ...

@app.route("/api/admin/atualizar-estoque", methods=['POST'])
def atualizar_estoque_admin():
    """
    Endpoint para que o administrador possa adicionar estoque a um produto.
    Esperamos um JSON com: { "id_produto": 1, "quantidade_a_adicionar": 10 }
    """
    print("LOG: Requisição /api/admin/atualizar-estoque recebida!")
    
    dados = request.get_json()
    id_produto = dados.get('id_produto')
    quantidade_a_adicionar = dados.get('quantidade_a_adicionar')

    # Validação básica
    if not isinstance(id_produto, int) or not isinstance(quantidade_a_adicionar, int) or quantidade_a_adicionar <= 0:
        return jsonify({"status": "erro", "mensagem": "Dados inválidos. id_produto deve ser inteiro e quantidade_a_adicionar um inteiro positivo."}), 400

    # Encontrar o produto no nosso DB
    produto_encontrado = None
    for produto in DB_PRODUTOS:
        if produto['id'] == id_produto:
            produto_encontrado = produto
            break

    if not produto_encontrado:
        return jsonify({"status": "erro", "mensagem": f"Produto com ID {id_produto} não encontrado."}), 404

    # Atualizar o estoque
    produto_encontrado['stock'] += quantidade_a_adicionar
    print(f"Estoque do produto '{produto_encontrado['nome']}' atualizado para: {produto_encontrado['stock']}")

    return jsonify({
        "status": "sucesso",
        "mensagem": f"Estoque de '{produto_encontrado['nome']}' atualizado. Novo estoque: {produto_encontrado['stock']}"
    })

# ... (o resto do app.py, como o if __name__ == "__main__":) ...  


# ... (após a função atualizar_estoque_admin) ...

@app.route("/api/admin/remover-estoque", methods=['POST'])
def remover_estoque_admin():
    """
    Endpoint para que o administrador possa remover estoque de um produto.
    Esperamos um JSON com: { "id_produto": 1, "quantidade_a_remover": 5 }
    """
    print("LOG: Requisição /api/admin/remover-estoque recebida!")
    
    dados = request.get_json()
    id_produto = dados.get('id_produto')
    quantidade_a_remover = dados.get('quantidade_a_remover')

    # Validação básica
    if not isinstance(id_produto, int) or not isinstance(quantidade_a_remover, int) or quantidade_a_remover <= 0:
        return jsonify({"status": "erro", "mensagem": "Dados inválidos. id_produto deve ser inteiro e quantidade_a_remover um inteiro positivo."}), 400

    # Encontrar o produto no nosso DB
    produto_encontrado = None
    for produto in DB_PRODUTOS:
        if produto['id'] == id_produto:
            produto_encontrado = produto
            break

    if not produto_encontrado:
        return jsonify({"status": "erro", "mensagem": f"Produto com ID {id_produto} não encontrado."}), 404

    # --- LÓGICA DE REMOÇÃO SEGURA ---
    if quantidade_a_remover > produto_encontrado['stock']:
        return jsonify({
            "status": "erro", 
            "mensagem": f"Não é possível remover {quantidade_a_remover} itens. Estoque atual de '{produto_encontrado['nome']}' é {produto_encontrado['stock']}."
        }), 400 # 400 = Bad Request (Requisição Inválida)

    # Atualizar o estoque
    produto_encontrado['stock'] -= quantidade_a_remover
    print(f"Estoque do produto '{produto_encontrado['nome']}' atualizado para: {produto_encontrado['stock']}")

    return jsonify({
        "status": "sucesso",
        "mensagem": f"Estoque de '{produto_encontrado['nome']}' atualizado. Novo estoque: {produto_encontrado['stock']}"
    })

# ... (o resto do app.py, como o if __name__ == "__main__":) ...


# --- Roda o Servidor ---
if __name__ == "__main__":
    app.run(debug=True, port=5000)