document.addEventListener("DOMContentLoaded", () => {
    console.log("Página inicial carregada. Buscando produtos...");
    
    // Tenta atualizar o contador do cabeçalho
    if (typeof atualizarContadorCarrinhoHeader === 'function') {
        atualizarContadorCarrinhoHeader();
    }
    
    carregarProdutos();
});

async function carregarProdutos() {
    const containerProdutos = document.getElementById("lista-produtos");
    
    try {
        const response = await fetch("http://127.0.0.1:5000/api/produtos");
        if (!response.ok) {
            throw new Error(`Erro na API: ${response.statusText}`);
        }
        
        const produtos = await response.json();
        containerProdutos.innerHTML = ""; 
        
        produtos.forEach(produto => {
            const card = document.createElement('div');
            card.className = 'card-produto';
            
            const img = document.createElement('img');
            img.src = produto.imagem;
            img.alt = produto.nome;
            card.appendChild(img);
            
            const nome = document.createElement('h3');
            nome.innerText = produto.nome;
            card.appendChild(nome);
            
            const preco = document.createElement('p');
            preco.innerText = `R$ ${produto.preco.toFixed(2).replace('.', ',')}`;
            card.appendChild(preco);

            // --- NOVO: MOSTRAR O ESTOQUE ---
            const estoque = document.createElement('p');
            estoque.className = 'produto-estoque'; // Nova classe CSS
            if (produto.stock > 0) {
                estoque.innerText = `Em estoque: ${produto.stock}`;
            } else {
                estoque.innerText = 'ESGOTADO';
                estoque.classList.add('esgotado'); // Classe especial
            }
            card.appendChild(estoque);

            // --- NOVO: LÓGICA DO BOTÃO ---
            const botao = document.createElement('button');
            botao.innerText = "Adicionar ao Carrinho";
            
            if (produto.stock > 0) {
                // Adiciona o 'escutador' de clique
                botao.addEventListener('click', () => {
                    adicionarAoCarrinho(produto);
                });
            } else {
                // Desabilita o botão se não houver estoque
                botao.disabled = true;
                botao.innerText = "Sem Estoque";
                botao.classList.add('btn-esgotado'); // Nova classe CSS
            }
            card.appendChild(botao);
            
            containerProdutos.appendChild(card);
        });

    } catch (error) {
        console.error("Falha ao carregar produtos:", error);
        containerProdutos.innerHTML = "<p>Não foi possível carregar os produtos. Tente novamente mais tarde.</p>";
    }
}

/**
 * --- FUNÇÃO REESCRITA PARA SUPORTAR QUANTIDADE ---
 */
function adicionarAoCarrinho(produto) {
    if (typeof getCarrinho !== 'function') {
        alert('Erro: script do carrinho não carregado.');
        return;
    }
    
    let carrinho = getCarrinho();
    
    // Procura se o item JÁ EXISTE no carrinho
    const itemIndex = carrinho.findIndex(item => item.id === produto.id);
    
    if (itemIndex > -1) {
        // Se existe, apenas incrementa a quantidade
        // Verificação de estoque (simples)
        if (carrinho[itemIndex].qtde < produto.stock) {
            carrinho[itemIndex].qtde++;
            alert(`${produto.nome} teve a quantidade aumentada!`);
        } else {
            alert(`Você já atingiu o limite de estoque para ${produto.nome}!`);
            return; // Para a função
        }
    } else {
        // Se não existe, adiciona o novo item com qtde: 1
        const novoItem = {
            id: produto.id,
            produto: produto, // Salva o objeto produto inteiro
            qtde: 1
        };
        carrinho.push(novoItem);
        alert(`${produto.nome} foi adicionado ao carrinho!`);
    }
    
    // Salva o carrinho atualizado no localStorage
    salvarCarrinho(carrinho);
}