/* --- NOVA ESTRUTURA DO CARRINHO ---
O localStorage não vai mais salvar [produto1, produto2].
Ele vai salvar um array de objetos, assim:
[
    { "id": 1, "produto": { ...dados do produto... }, "qtde": 2 },
    { "id": 5, "produto": { ...dados do produto... }, "qtde": 1 }
]
*/

document.addEventListener("DOMContentLoaded", () => {
    // Atualiza o contador no cabeçalho em todas as páginas
    atualizarContadorCarrinhoHeader();
    
    // O resto do código só deve rodar se estivermos na página do carrinho
    const containerItens = document.getElementById("itens-carrinho");
    if (containerItens) {
        carregarItensCarrinho();
        
        // Adiciona o 'escutador' para o botão de finalizar compra
        const btnFinalizar = document.querySelector('.btn-finalizar');
        if (btnFinalizar) {
            btnFinalizar.addEventListener('click', processarCompra);
        }
    }
});

function getCarrinho() {
    // Pega o carrinho do localStorage ou retorna um array vazio
    return JSON.parse(localStorage.getItem('carrinho')) || [];
}

function salvarCarrinho(carrinho) {
    // Salva o carrinho de volta no localStorage
    localStorage.setItem('carrinho', JSON.stringify(carrinho));
    // Atualiza o contador em qualquer mudança
    atualizarContadorCarrinhoHeader();
}

function carregarItensCarrinho() {
    const carrinho = getCarrinho();
    const containerItens = document.getElementById("itens-carrinho");
    const elTotal = document.getElementById("total-carrinho");
    
    containerItens.innerHTML = ""; // Limpa o container
    let total = 0;

    if (carrinho.length === 0) {
        containerItens.innerHTML = "<p style='font-size: 1.5rem;'>Seu carrinho está vazio.</p>";
        elTotal.innerText = "Total: R$ 0,00";
        return;
    }

    carrinho.forEach(item => {
        const produto = item.produto;
        const subtotal = produto.preco * item.qtde;
        total += subtotal; // Soma o subtotal (preço * qtde)
        
        const itemHTML = `
            <div class="item-carrinho">
                <img src="${produto.imagem}" alt="${produto.nome}">
                <div class="info">
                    <h3>${produto.nome}</h3>
                    <p>R$ ${produto.preco.toFixed(2).replace('.', ',')}</p>
                </div>
                
                <div class="seletor-qtde">
                    <button class="btn-qtde" onclick="mudarQuantidade(${produto.id}, -1)">-</button>
                    <span>${item.qtde}</span>
                    <button class="btn-qtde" onclick="mudarQuantidade(${produto.id}, 1)">+</button>
                </div>
                
                <p class="subtotal">Subtotal: R$ ${subtotal.toFixed(2).replace('.', ',')}</p>

                <button class="btn-remover" onclick="removerItemDoCarrinho(${produto.id})">
                    Remover
                </button>
            </div>
        `;
        containerItens.innerHTML += itemHTML;
    });

    // Atualiza o texto do total
    elTotal.innerText = `Total: R$ ${total.toFixed(2).replace('.', ',')}`;
}

function mudarQuantidade(idProduto, delta) {
    // delta pode ser +1 ou -1
    let carrinho = getCarrinho();
    const itemIndex = carrinho.findIndex(item => item.id === idProduto);
    
    if (itemIndex > -1) {
        carrinho[itemIndex].qtde += delta;
        
        // Se a quantidade chegar a 0, remove o item
        if (carrinho[itemIndex].qtde <= 0) {
            carrinho.splice(itemIndex, 1); // Remove o item do array
        }
        
        salvarCarrinho(carrinho);
        carregarItensCarrinho(); // Recarrega os itens na página
    }
}

function removerItemDoCarrinho(idProduto) {
    let carrinho = getCarrinho();
    // Cria um novo array sem o produto que queremos remover
    const novoCarrinho = carrinho.filter(item => item.id !== idProduto);
    salvarCarrinho(novoCarrinho);
    carregarItensCarrinho(); // Recarrega os itens na página
}

function atualizarContadorCarrinhoHeader() {
    // Esta função agora SOMA as quantidades, em vez de contar os itens
    const carrinho = getCarrinho();
    const linkCarrinho = document.getElementById("link-carrinho");
    
    // 'reduce' soma a 'qtde' de cada item, começando em 0
    const totalItens = carrinho.reduce((total, item) => total + item.qtde, 0);
    
    if (linkCarrinho) {
        linkCarrinho.innerText = `Carrinho (${totalItens})`;
    }
}

// --- FUNÇÃO MAIS IMPORTANTE: FINALIZAR A COMPRA ---
async function processarCompra() {
    let carrinho = getCarrinho();
    
    // 1. Formata o carrinho para enviar à API (só IDs e qtde)
    const carrinhoParaAPI = carrinho.map(item => {
        return {
            id: item.id,
            qtde: item.qtde
        };
    });
}