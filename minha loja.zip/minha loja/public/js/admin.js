document.addEventListener("DOMContentLoaded", () => {
    // Atualiza o contador do carrinho no cabeçalho (função do carrinho.js)
    if (typeof atualizarContadorCarrinhoHeader === 'function') {
        atualizarContadorCarrinhoHeader();
    }

    carregarProdutosAdmin(); // Carrega produtos para a lista e os selects
    
    // Escutador para o formulário de ADICIONAR
    const formEstoque = document.getElementById("form-atualizar-estoque");
    if (formEstoque) {
        formEstoque.addEventListener('submit', enviarAtualizacaoEstoque);
    }

    // --- NOVO: Escutador para o formulário de REMOVER ---
    const formRemoverEstoque = document.getElementById("form-remover-estoque");
    if (formRemoverEstoque) {
        formRemoverEstoque.addEventListener('submit', enviarRemocaoEstoque);
    }
});

/**
 * Carrega os produtos da API para:
 * 1. Popular o <select> do formulário de ADIÇÃO.
 * 2. Popular o <select> do formulário de REMOÇÃO.
 * 3. Listar o estoque atual dos produtos.
 */
async function carregarProdutosAdmin() {
    const produtoSelectAdd = document.getElementById("produto-select");
    const produtoSelectRemove = document.getElementById("produto-select-remover"); // <-- NOVO SELECT
    const listaProdutosAdmin = document.getElementById("lista-produtos-admin");

    try {
        const response = await fetch("http://127.0.0.1:5000/api/produtos");
        if (!response.ok) {
            throw new Error(`Erro na API: ${response.statusText}`);
        }
        
        const produtos = await response.json();
        
        // Limpar e popular os selects
        const defaultOption = '<option value="">-- Selecione um produto --</option>';
        produtoSelectAdd.innerHTML = defaultOption;
        produtoSelectRemove.innerHTML = defaultOption; // <-- LIMPA O NOVO SELECT
        
        produtos.forEach(produto => {
            const option = document.createElement('option');
            option.value = produto.id;
            option.innerText = `${produto.nome} (Estoque: ${produto.stock})`;
            
            produtoSelectAdd.appendChild(option);
            produtoSelectRemove.appendChild(option.cloneNode(true)); // <-- ADICIONA AO NOVO SELECT
        });

        // Limpar e listar o estoque atual
        listaProdutosAdmin.innerHTML = '';
        if (produtos.length === 0) {
            listaProdutosAdmin.innerHTML = '<p>Nenhum produto encontrado.</p>';
        } else {
            produtos.forEach(produto => {
                const p = document.createElement('p');
                p.innerHTML = `<strong>${produto.nome}:</strong> Estoque atual: <span class="${produto.stock <= 5 ? 'estoque-baixo' : ''}">${produto.stock}</span>`;
                listaProdutosAdmin.appendChild(p);
            });
        }

    } catch (error) {
        console.error("Falha ao carregar produtos para o admin:", error);
        if (listaProdutosAdmin) {
            listaProdutosAdmin.innerHTML = '<p class="admin-error">Não foi possível carregar os produtos. Verifique o servidor da API.</p>';
        }
    }
}

/**
 * Envia a requisição POST para ADICIONAR estoque.
 */
async function enviarAtualizacaoEstoque(event) {
    event.preventDefault(); // Impede o recarregamento da página

    const produtoSelect = document.getElementById("produto-select");
    const quantidadeInput = document.getElementById("quantidade-input");
    const adminFeedback = document.getElementById("admin-feedback");
    const formEstoque = document.getElementById("form-atualizar-estoque");
    
    const idProduto = parseInt(produtoSelect.value);
    const quantidade = parseInt(quantidadeInput.value);

    // Validação frontend (básica)
    if (!idProduto || isNaN(idProduto) || quantidade <= 0 || isNaN(quantidade)) {
        adminFeedback.className = 'admin-feedback admin-error';
        adminFeedback.innerText = 'Por favor, selecione um produto e digite uma quantidade válida (maior que 0).';
        return;
    }

    adminFeedback.className = 'admin-feedback admin-loading';
    adminFeedback.innerText = 'Atualizando estoque...';

    try {
        const response = await fetch("http://127.0.0.1:5000/api/admin/atualizar-estoque", {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                id_produto: idProduto,
                quantidade_a_adicionar: quantidade
            })
        });

        const resultado = await response.json();

        if (response.ok) {
            adminFeedback.className = 'admin-feedback admin-success';
            adminFeedback.innerText = resultado.mensagem;
            formEstoque.reset(); 
            carregarProdutosAdmin(); // Recarrega a lista de produtos
        } else {
            adminFeedback.className = 'admin-feedback admin-error';
            adminFeedback.innerText = resultado.mensagem || 'Ocorreu um erro ao atualizar o estoque.';
        }

    } catch (error) {
        adminFeedback.className = 'admin-feedback admin-error';
        adminFeedback.innerText = 'Não foi possível conectar ao servidor da API.';
    }
}

/**
 * --- NOVA FUNÇÃO ---
 * Envia a requisição POST para REMOVER estoque.
 */
async function enviarRemocaoEstoque(event) {
    event.preventDefault(); // Impede o recarregamento da página

    const produtoSelect = document.getElementById("produto-select-remover");
    const quantidadeInput = document.getElementById("quantidade-remover-input");
    const adminFeedback = document.getElementById("admin-feedback-remover");
    const formRemoverEstoque = document.getElementById("form-remover-estoque");
    
    const idProduto = parseInt(produtoSelect.value);
    const quantidade = parseInt(quantidadeInput.value);

    // Validação
    if (!idProduto || isNaN(idProduto) || quantidade <= 0 || isNaN(quantidade)) {
        adminFeedback.className = 'admin-feedback admin-error';
        adminFeedback.innerText = 'Por favor, selecione um produto e digite uma quantidade válida (maior que 0).';
        return;
    }

    adminFeedback.className = 'admin-feedback admin-loading';
    adminFeedback.innerText = 'Removendo estoque...';

    try {
        const response = await fetch("http://127.0.0.1:5000/api/admin/remover-estoque", { // <-- NOVO ENDPOINT
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                id_produto: idProduto,
                quantidade_a_remover: quantidade // <-- NOME CORRETO DA CHAVE
            })
        });

        const resultado = await response.json();

        if (response.ok) {
            adminFeedback.className = 'admin-feedback admin-success';
            adminFeedback.innerText = resultado.mensagem;
            formRemoverEstoque.reset(); 
            carregarProdutosAdmin(); // Recarrega a lista de produtos
        } else {
            adminFeedback.className = 'admin-feedback admin-error';
            adminFeedback.innerText = resultado.mensagem || 'Ocorreu um erro ao remover o estoque.';
        }

    } catch (error) {
        adminFeedback.className = 'admin-feedback admin-error';
        adminFeedback.innerText = 'Não foi possível conectar ao servidor da API.';
    }
}