document.addEventListener("DOMContentLoaded", () => {
    const formLogin = document.getElementById("form-admin-login");
    if (formLogin) {
        formLogin.addEventListener('submit', verificarSenhaAdmin);
    }
});

function verificarSenhaAdmin(event) {
    event.preventDefault(); // Impede o recarregamento da página

    const senhaInput = document.getElementById("senha-input");
    const loginFeedback = document.getElementById("login-feedback");
    
    const senhaCorreta = "072007"; // A SENHA SECRETA!
    const senhaDigitada = senhaInput.value;

    if (senhaDigitada === senhaCorreta) {
        // Senha correta!
        loginFeedback.className = 'admin-feedback admin-success';
        loginFeedback.innerText = 'Login bem-sucedido! Redirecionando...';
        
        // Armazena um token no sessionStorage (válido enquanto a aba estiver aberta)
        sessionStorage.setItem('admin_logado', 'true');
        
        // Redireciona para a página de administração
        setTimeout(() => {
            window.location.href = 'admin.html';
        }, 1000); // Espera 1 segundo para mostrar a mensagem
        
    } else {
        // Senha incorreta
        loginFeedback.className = 'admin-feedback admin-error';
        loginFeedback.innerText = 'Senha incorreta. Tente novamente.';
        senhaInput.value = ''; // Limpa o campo da senha
        senhaInput.focus(); // Coloca o foco de volta no campo
    }
}