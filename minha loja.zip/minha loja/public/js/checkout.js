document.addEventListener("DOMContentLoaded", () => {
    // Atualiza o contador do carrinho no cabeçalho (função do carrinho.js)
    if (typeof atualizarContadorCarrinhoHeader === 'function') {
        atualizarContadorCarrinhoHeader();
    }
    
    carregarResumoPedido();

    const formCheckout = document.getElementById("form-checkout");
    if (formCheckout) {
        formCheckout.addEventListener('submit', finalizarPedido);
    }
});

/**
 * Carrega os itens do carrinho e os exibe como um resumo na página de checkout.
 */
function carregarResumoPedido() {
    const carrinho = getCarrinho(); // getCarrinho() vem de carrinho.js
    const resumoPedidoDiv = document.getElementById("resumo-pedido");
    const totalPedidoH3 = document.getElementById("total-pedido");

    resumoPedidoDiv.innerHTML = ""; // Limpa o container
    let total = 0;

    if (carrinho.length === 0) {
        resumoPedidoDiv.innerHTML = "<p style='font-size: 1.5rem;'>Seu carrinho está vazio. Por favor, adicione itens antes de finalizar a compra.</p>";
        totalPedidoH3.innerText = "Total: R$ 0,00";
        // Desabilitar o formulário ou o botão de finalizar se o carrinho estiver vazio
        const btnCheckout = document.querySelector('.btn-checkout');
        if (btnCheckout) btnCheckout.disabled = true;
        return;
    }

    carrinho.forEach(item => {
        const produto = item.produto;
        const subtotal = produto.preco * item.qtde;
        total += subtotal;
        
        const itemHTML = `
            <div class="item-resumo-checkout">
                <img src="${produto.imagem}" alt="${produto.nome}">
                <div class="info">
                    <h3>${produto.nome}</h3>
                    <p>Quantidade: ${item.qtde}</p>
                    <p>Preço unitário: R$ ${produto.preco.toFixed(2).replace('.', ',')}</p>
                </div>
                <p class="subtotal">R$ ${subtotal.toFixed(2).replace('.', ',')}</p>
            </div>
        `;
        resumoPedidoDiv.innerHTML += itemHTML;
    });

    totalPedidoH3.innerText = `Total: R$ ${total.toFixed(2).replace('.', ',')}`;
}

/**
 * Coleta os dados do formulário e envia o pedido final para a API.
 */
async function finalizarPedido(event) {
    event.preventDefault(); // Impede o recarregamento da página

    const form = event.target;
    const formData = new FormData(form);
    const dadosEntrega = {};
    formData.forEach((value, key) => { dadosEntrega[key] = value; });

    const carrinho = getCarrinho(); // Pega o carrinho atualizado
    
    if (carrinho.length === 0) {
        alert("Seu carrinho está vazio! Por favor, adicione itens para finalizar a compra.");
        return;
    }

    // Formata o carrinho para enviar à API (só IDs e qtde)
    const carrinhoParaAPI = carrinho.map(item => {
        return {
            id: item.id,
            qtde: item.qtde
        };
    });

    const checkoutFeedback = document.getElementById("checkout-feedback");
    const btnCheckout = document.querySelector('.btn-checkout');
    
    btnCheckout.disabled = true;
    btnCheckout.innerText = "Processando Pedido...";
    checkoutFeedback.className = 'admin-feedback admin-loading';
    checkoutFeedback.innerText = 'Verificando estoque e finalizando pedido...';

    try {
        const response = await fetch("http://127.0.0.1:5000/api/finalizar-compra", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                carrinho: carrinhoParaAPI,
                dados_entrega: dadosEntrega // Inclui os dados do formulário
            })
        });

        const resultado = await response.json();

        if (response.ok) { // Status 200-299
            checkoutFeedback.className = 'admin-feedback admin-success';
            checkoutFeedback.innerText = resultado.mensagem; // "Compra realizada com sucesso!"
            salvarCarrinho([]); // Limpa o carrinho
            
            // Redireciona para uma página de sucesso ou Home
            setTimeout(() => {
                alert("Obrigado pela sua compra!");
                window.location.href = 'index.html';
            }, 2000); 

        } else {
            // Erro (ex: falta de estoque)
            checkoutFeedback.className = 'admin-feedback admin-error';
            checkoutFeedback.innerText = resultado.mensagem; 
            btnCheckout.disabled = false;
            btnCheckout.innerText = "Confirmar Pedido";
            alert("Erro ao finalizar compra: " + resultado.mensagem);
        }
    } catch (error) {
        console.error("Erro ao processar checkout:", error);
        checkoutFeedback.className = 'admin-feedback admin-error';
        checkoutFeedback.innerText = 'Não foi possível conectar ao servidor. Tente novamente.';
        btnCheckout.disabled = false;
        btnCheckout.innerText = "Confirmar Pedido";
    }
}   